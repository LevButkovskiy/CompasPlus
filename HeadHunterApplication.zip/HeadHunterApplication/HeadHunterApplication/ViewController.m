//
//  ViewController.m
//  HeadHunterApplication
//
//  Created by Lev Butkovskiy on 19/10/2018.
//  Copyright © 2018 Lev Butkovskiy. All rights reserved.
//

#import "ViewController.h"

@interface UIViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    //Initialization Company(-es)
    BLCompany *Company = [[BLCompany alloc] initWithString:(@"CompanyName") andID:0];
    BLCompany *Company2 = [[BLCompany alloc] initWithString:(@"CompanyName2") andID:1];
    
    //Initialization of array
    BLCompanies *arrayOfCompanies = [[BLCompanies alloc]initWithArray];
    //Adding Company(-es) to array
    [arrayOfCompanies addCompany:Company];
    [arrayOfCompanies addCompany:Company2];
    
  //  NSLog(@"%i)Company name:%@",Company.ID, Company.Name);
    
    //------------------------------------API-----------------------------------//
    /*    NSURLSession *session = NSURLSession.sharedSession;

        //https://developer.apple.com/documentation/foundation/nsurl
        NSURL *baseURL = [NSURL fileURLWithPath:@"file:///path/to/user/"];
        NSURL *URL = [NSURL URLWithString:@"folder/file.html" relativeToURL:baseURL];
        NSLog(@"absoluteURL = %@", [URL absoluteURL]);

        //
     */   // NSURLSessionDataTask *dataTask = [session.];
    //------------------------------------------------------------------------//
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

@end
