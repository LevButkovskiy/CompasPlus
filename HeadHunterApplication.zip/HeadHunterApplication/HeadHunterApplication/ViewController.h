//
//  ViewController.h
//  HeadHunterApplication
//
//  Created by Lev Butkovskiy on 19/10/2018.
//  Copyright © 2018 Lev Butkovskiy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLCompanies.h"

@interface ViewController : UIViewController

@end

